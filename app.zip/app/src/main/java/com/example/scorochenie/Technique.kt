package com.example.scorochenie

data class Technique(val name: String, val description: String? = null)